def greet(name:str):
    return f"hello name:{name}"